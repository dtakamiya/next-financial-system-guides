# 第6章：堅牢なサービスを作るためのモダンなテスト戦略

マイクロサービスアーキテクチャでは、単一サービスの品質だけでなく、サービス間の連携が正しく行われることを保証することが極めて重要になります。この章では、システムの信頼性を高めるためのモダンなテスト戦略を解説します。

## テスト戦略の全体像（テストピラミッド）

私たちのテスト戦略は、伝統的なテストピラミッドに基づきますが、マイクロサービスの文脈に合わせて調整されています。

```mermaid
graph TD
    subgraph "テストピラミッド"
        direction TB
        E2E["E2Eテスト"]
        Contract["契約テスト"]
        Integration["結合テスト (with Testcontainers)"]
        Unit["単体テスト (Domain/Util)"]
        
        Unit -- "Fast & Cheap" --> Integration
        Integration -- "More Integrated" --> Contract
        Contract -- "More Integrated" --> E2E
    end

    style Unit fill:#cfc,stroke:#333,stroke-width:2px
    style Integration fill:#ffc,stroke:#333,stroke-width:2px
    style Contract fill:#f9c,stroke:#333,stroke-width:2px
    style E2E fill:#f66,stroke:#333,stroke-width:2px
```
- **単体テスト (Unit Tests)**: 最も数が多く、高速に実行できる。ドメインモデルのビジネスロジックなどを検証。
- **結合テスト (Integration Tests)**: DBやメッセージブローカーなど、外部インフラと正しく連携できるかを検証。
- **契約テスト (Contract Tests)**: サービス間のAPI仕様（契約）が守られているかを検証。
- **E2Eテスト (End-to-End Tests)**: ユーザー視点で、複数のサービスをまたがるビジネスシナリオ全体を検証。数は最小限に抑える。

## 6.1. 単体テスト (Spock)

- **対象**: ドメインモデル、ユーティリティクラスなど、外部依存のない純粋なロジック。
- **目的**: ビジネスルールが正しく実装されていることを検証する。
- **ツール**: Spock Framework

**ドメインモデルのテスト例 (`AccountSpec.groovy`)**
```groovy
class AccountSpec extends Specification {
    def "withdrawing more than the balance should fail"() {
        given: "an account with a balance of 1000 JPY"
        def account = new Account(
            new AccountId("acc-1"), new CustomerId("cust-1"), 
            new Money(new BigDecimal("1000"), "JPY"), 1L
        )
        def amountToWithdraw = new Money(new BigDecimal("2000"), "JPY")

        when: "attempting to withdraw 2000 JPY"
        account.withdraw(amountToWithdraw)

        then: "an InsufficientBalanceException should be thrown"
        thrown(InsufficientBalanceException)
    }
}
```

## 6.2. 結合テスト (Spock + Testcontainers)

インメモリDB（H2など）は手軽ですが、本番環境のDB（PostgreSQL, MySQLなど）との微妙な挙動の違いにより、テストは通るのに本番ではバグが発生する、という問題が起こり得ます。

**Testcontainers**は、Dockerコンテナを使って、テスト実行時に本番と同じDBやメッセージブローカーをプログラムから起動できるライブラリです。これにより、テストの信頼性が飛躍的に向上します。

- **対象**: リポジトリ実装、メッセージングクライアントなど、インフラ層のコード。
- **目的**: 外部インフラ（DB、ブローカー）と正しく通信できることを検証する。
- **ツール**: Spock, Testcontainers, Spring Boot Test

**リポジトリの結合テスト例 (`MyBatisAccountRepositorySpec.groovy`)**
```groovy
@SpringBootTest
@Testcontainers // Testcontainersを有効化
class MyBatisAccountRepositorySpec extends Specification {

    @Autowired
    AccountRepository accountRepository // テスト対象

    // PostgreSQLコンテナを定義
    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15-alpine")

    // コンテナの情報をSpringのデータソース設定に動的に反映
    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl)
        registry.add("spring.datasource.username", postgres::getUsername)
        registry.add("spring.datasource.password", postgres::getPassword)
    }

    def "saved account should be retrievable"() {
        given: "a new account"
        def accountId = new AccountId(UUID.randomUUID().toString())
        def account = new Account(accountId, new CustomerId("cust-123"))

        when: "the account is saved"
        accountRepository.save(account)

        then: "it can be found by its id"
        def found = accountRepository.findById(accountId)
        found.isPresent()
        found.get().customerId == account.customerId
    }
}
```

## 6.3. 契約テスト (Spring Cloud Contract)

マイクロサービス開発では、「サービスAのAPI仕様変更が、それに依存するサービスBを壊してしまう」という問題が頻繁に起こります。**契約テスト**は、この問題をCI/CDパイプラインの早い段階で検知するための仕組みです。

**仕組み:**
1.  **Consumer（利用者側）** は、「私はProvider（提供者側）のAPIに、こういうリクエストを送ったら、こういうレスポンスが返ってきてほしい」という**契約 (Contract)** を定義します。
2.  **Provider（提供者側）** は、CIでその契約定義を元に自動生成されたテストを実行し、自身のAPIが契約通りの振る舞いをすることを保証します。
3.  契約は共有リポジトリ（GitやArtifactory）で管理され、両サービスが常に同じ契約を参照します。

- **対象**: サービス間のAPI（REST, Messaging）。
- **目的**: APIの仕様（リクエスト/レスポンス形式、ステータスコードなど）の互換性を保証する。
- **ツール**: Spring Cloud Contract

**契約定義の例 (`shouldReturnAccount.groovy`)**
これはConsumer側が記述する契約の定義ファイルです。
```groovy
// contracts/account-service/
package contracts.accounts

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    request {
        method 'GET'
        url '/accounts/12345'
    }
    response {
        status 200
        headers {
            contentType('application/json')
        }
        body(
            accountId: '12345',
            customerId: 'cust-abc',
            balance: [
                amount: 100.00,
                currency: 'JPY'
            ]
        )
    }
}
```
この契約を元に、Provider（`account-service`）側では自動的にテストが生成・実行され、Consumer側ではAPIをモックするスタブが生成されます。これにより、両者は独立して開発・テストを進めつつ、結合時の問題を未然に防ぐことができます。 
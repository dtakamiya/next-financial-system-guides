# TODO: guide05 - 統合版・実践DDDマイクロサービス開発マスターガイド

## 概要

`guide05`は、これまでに作成された全てのガイド (`docs`, `guide01`〜`04`) の内容を統合、整理、再構築した、ドメイン駆動設計（DDD）によるマイクロサービス開発の **決定版マスターガイド** です。金融システムを題材に、理論から実践、テスト、応用までを網羅し、一貫した学習体験を提供します。

**キーワード:** 金融システム, マイクロサービスアーキテクチャ, オニオンアーキテクチャ, Java17, SpringBoot, Spock

## ゴール

-   DDDの理論と実践に関する断片的な知識を、単一の体系的なガイドに集約する。
-   初心者から中級者までが、自身のレベルに合わせて学び進められる、網羅的かつ階層的なコンテンツを提供する。
-   実際の金融システム開発で直面する課題（ドメインモデリング、サービス間連携、テスト、etc.）に対する、具体的かつ実践的な解決策を提示する。

---

## Part 1: 理論編 - DDDの基礎を固める
- [x] **Chapter 1: DDDへようこそ (`01_Introduction.md`)**
- [x] **Chapter 2: 戦略的設計 - ビジネスとコードを繋ぐ (`02_Strategic_Design.md`)**
- [x] **Chapter 3: 戦術的設計 - ドメインモデルの構成要素 (`03_Tactical_Design.md`)**
- [x] **Chapter 4: ドメインイベント - システムの「時」を捉える (`04_Domain_Events.md`)**

---

## Part 2: 設計編 - 変化に強いアーキテクチャ
- [x] **Chapter 5: アーキテクチャの選択 - クリーンアーキテクチャを中心に (`05_Architecture_Choice.md`)**
- [x] **Chapter 6: マイクロサービスとイベント駆動 (`06_Microservices_And_Events.md`)**

---

## Part 3: 実践編 - コードでDDDを体現する
- [x] **Chapter 7: 開発環境のセットアップ (`07_Development_Environment.md`)**
- [x] **Chapter 8: 集約（Aggregate）の実装 (`08_Aggregate_Implementation.md`)**
- [x] **Chapter 9: リポジトリと永続化 (`09_Repository_And_Persistence.md`)**
- [x] **Chapter 10: アプリケーションサービスとドメインサービス (`10_Application_And_Domain_Services.md`)**

---

## Part 4: 品質編 - 信頼性を高めるテストとパターン
- [x] **Chapter 11: CQRS - コマンドとクエリの分離 (`11_CQRS.md`)**
- [x] **Chapter 12: Sagaパターン - 分散トランザクションの管理 (`12_Saga_Pattern.md`)**
- [x] **Chapter 13: モダンなテスト戦略 (`13_Modern_Testing_Strategy.md`)**
- [x] **Chapter 14: APIゲートウェイとBFF (`14_API_Gateway_And_BFF.md`)**

---

## Part 5: 応用編 - DDDをさらに活用する
- [x] **Chapter 15: 金融システム特有のパターン (`15_Financial_System_Patterns.md`)**
    - `guide02/05_financial_system_patterns.md` と `guide03/06_Financial_System_Design.md` を統合し、高可用性、セキュリティ、監査証跡などの要件に対応する設計パターンを解説。
- [x] **Chapter 16: FAQとトラブルシューティング (`16_FAQ.md`)**
    - `guide02/B_faq.md` を基に、よくある質問とその回答をまとめる。
- [x] **Chapter 17: 用語集 (`17_Glossary.md`)**
    - `guide02/C_glossary.md` を基に、DDD関連用語の定義を一覧化する。
- [x] **Chapter 18: 次のステップへ (`18_Conclusion.md`)**
    - 全体のまとめと、今後の学習リソースやコミュニティへのリンクを提供する。 